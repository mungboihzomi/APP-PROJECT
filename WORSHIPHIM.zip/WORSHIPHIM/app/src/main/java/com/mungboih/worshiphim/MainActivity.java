package com.mungboih.worshiphim;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Theme ကို setContentView မလုပ်ခင် apply ရမယ်
        ThemeHelper.applyTheme(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNav = findViewById(R.id.bottomNav);

        loadFragment(new HomeFragment());

        bottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
				@Override
				public boolean onNavigationItemSelected(@NonNull MenuItem item) {
					Fragment selected = null;
					int id = item.getItemId();
					if (id == R.id.nav_home) {
						selected = new HomeFragment();
					} else if (id == R.id.nav_fav) {
						selected = new FavFragment();
					} else if (id == R.id.nav_settings) {
						selected = new SettingsFragment();
					}
					if (selected != null) {
						loadFragment(selected);
						return true;
					}
					return false;
				}
			});
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
			.replace(R.id.fragmentContainer, fragment)
			.commit();
    }
}
