package com.mungboih.worshiphim;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import org.json.JSONObject;
import java.util.ArrayList;

public class HymnAdapter extends RecyclerView.Adapter<HymnAdapter.ViewHolder> {

    public interface OnHymnClickListener { void onClick(JSONObject hymn); }

    private Context context;
    private ArrayList<JSONObject> list;
    private OnHymnClickListener listener;

    public HymnAdapter(Context context, ArrayList<JSONObject> list, OnHymnClickListener listener) {
        this.context = context;
        this.list = list;
        this.listener = listener;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView number, title, type, key;
        public ViewHolder(View itemView) {
            super(itemView);
            number = itemView.findViewById(R.id.itemNumber);
            title = itemView.findViewById(R.id.itemTitle);
            type = itemView.findViewById(R.id.itemType);
            key = itemView.findViewById(R.id.itemKey);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_hymn, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final JSONObject hymn = list.get(position);
        holder.number.setText(hymn.optString("number","-"));
        holder.title.setText(hymn.optString("title","No Title"));
        holder.type.setText(hymn.optString("type","") + " • " + hymn.optString("language",""));

        String k = hymn.optString("key","");
        if(k.isEmpty() || k.equals("null")) {
            holder.key.setVisibility(View.GONE);
        } else {
            holder.key.setVisibility(View.VISIBLE);
            holder.key.setText(k);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { listener.onClick(hymn); }
			});
    }

    @Override public int getItemCount() { return list.size(); }
}
