package com.mungboih.worshiphim;

public class Hymn {
    public int number;
    public String language;
    public String type;
    public String title;
    public String key;
    public String body;
}
