package com.mungboih.worshiphim;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import static android.content.Context.MODE_PRIVATE;

public class FavFragment extends Fragment {
    private final ArrayList<JSONObject> favHymns = new ArrayList<JSONObject>();
    private RecyclerView recyclerView;
    private TextView status;
    private HymnAdapter adapter;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        int BG = ThemeHelper.getBackground(getContext());
        int TEXT = ThemeHelper.getTextColor(getContext());
        int SUB = ThemeHelper.getSubTextColor(getContext());

        LinearLayout root = new LinearLayout(getContext());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        TextView title = new TextView(getContext());
        title.setText("MY FAVORITES");
        title.setTextColor(TEXT);
        title.setTextSize(18);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(20), 0, dp(10));
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(60)));

        status = new TextView(getContext());
        status.setTextColor(SUB);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(40)));

        recyclerView = new RecyclerView(getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setBackgroundColor(BG);
        adapter = new HymnAdapter(getContext(), favHymns, new HymnAdapter.OnHymnClickListener() {
				@Override public void onClick(JSONObject hymn) { openDetail(hymn); }
			});
        recyclerView.setAdapter(adapter);
        root.addView(recyclerView, new LinearLayout.LayoutParams(-1, 0, 1f));
        loadFavs();
        return root;
    }
    @Override public void onResume() { super.onResume(); loadFavs(); }
    private void loadFavs(){
        favHymns.clear();
        SharedPreferences prefIds = getContext().getSharedPreferences("favorites", MODE_PRIVATE);
        SharedPreferences prefData = getContext().getSharedPreferences("fav_data", MODE_PRIVATE);
        Set<String> favIds = prefIds.getStringSet("fav_ids", new HashSet<String>());
        if (favIds.isEmpty()) {
            status.setText("No favorites yet.\nTap ⭐ in song detail to add.");
            adapter.notifyDataSetChanged(); return;
        }
        for (String id : favIds) {
            String jsonStr = prefData.getString(id, null);
            if (jsonStr != null) { try { favHymns.add(new JSONObject(jsonStr)); } catch (Exception e){} }
        }
        status.setText("Total Favorites: " + favHymns.size());
        adapter.notifyDataSetChanged();
    }
    private void openDetail(JSONObject hymn){
        Intent intent = new Intent(getContext(), DetailActivity.class);
        intent.putExtra("number", hymn.optString("number",""));
        intent.putExtra("language", hymn.optString("language",""));
        intent.putExtra("type", hymn.optString("type",""));
        intent.putExtra("title", hymn.optString("title",""));
        intent.putExtra("key", hymn.optString("key",""));
        intent.putExtra("body", hymn.optString("body",""));
        startActivity(intent);
    }
    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}
