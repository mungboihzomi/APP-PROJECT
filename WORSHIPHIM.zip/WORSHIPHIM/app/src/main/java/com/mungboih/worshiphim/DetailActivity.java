package com.mungboih.worshiphim;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.util.HashSet;
import java.util.Set;

public class DetailActivity extends AppCompatActivity {

    private TextView tvNumber, tvTitle, tvType, tvKey, tvBody;
    private ImageButton btnFav;
    private String number, language, type, title, key, body;
    private String favId;
    private boolean isFav = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeHelper.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        int BG = ThemeHelper.getBackground(this);
        int TEXT = ThemeHelper.getTextColor(this);
        int SUB = ThemeHelper.getSubTextColor(this);

        findViewById(R.id.detailRoot).setBackgroundColor(BG);

        tvNumber = findViewById(R.id.tvNumber);
        tvTitle = findViewById(R.id.tvTitle);
        tvType = findViewById(R.id.tvType);
        tvKey = findViewById(R.id.tvKey);
        tvBody = findViewById(R.id.tvBody);
        ImageButton btnBack = findViewById(R.id.btnBack);
        ImageButton btnShare = findViewById(R.id.btnShare);
        btnFav = findViewById(R.id.btnFav);

        number = getIntent().getStringExtra("number");
        language = getIntent().getStringExtra("language");
        type = getIntent().getStringExtra("type");
        title = getIntent().getStringExtra("title");
        key = getIntent().getStringExtra("key");
        body = getIntent().getStringExtra("body");
        if (title == null) title = "";
        if (body == null) body = "";
        favId = language + "_" + type + "_" + number;

        tvNumber.setText("#" + number);
        tvTitle.setText(title); tvTitle.setTextColor(TEXT);
        tvType.setText(type + " • " + language); tvType.setTextColor(SUB);
        tvBody.setText(body); tvBody.setTextColor(TEXT);
        tvBody.setMovementMethod(new ScrollingMovementMethod());

        if (key != null && !key.trim().isEmpty() && !key.equals("null")) {
            tvKey.setVisibility(View.VISIBLE);
            tvKey.setText("Key: " + key);
        } else tvKey.setVisibility(View.GONE);

        checkFavStatus(); updateFavIcon();

        btnBack.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { finish(); }
			});
        btnFav.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) { toggleFav(); }
			});
        btnShare.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					android.content.Intent share = new android.content.Intent(android.content.Intent.ACTION_SEND);
					share.setType("text/plain");
					share.putExtra(android.content.Intent.EXTRA_TEXT, title + "\n\n" + body);
					startActivity(android.content.Intent.createChooser(share, "Share Song"));
				}
			});
    }

    private void checkFavStatus(){
        SharedPreferences pref = getSharedPreferences("favorites", MODE_PRIVATE);
        Set<String> favSet = pref.getStringSet("fav_ids", new HashSet<String>());
        isFav = favSet.contains(favId);
    }
    private void updateFavIcon(){
        if (isFav) {
            btnFav.setImageResource(android.R.drawable.btn_star_big_on);
            btnFav.setColorFilter(Color.rgb(255, 215, 0));
        } else {
            btnFav.setImageResource(android.R.drawable.btn_star_big_off);
            btnFav.setColorFilter(Color.rgb(138, 156, 176));
        }
    }
    private void toggleFav(){
        SharedPreferences pref = getSharedPreferences("favorites", MODE_PRIVATE);
        Set<String> favIds = pref.getStringSet("fav_ids", new HashSet<String>());
        Set<String> newIds = new HashSet<String>(favIds);
        SharedPreferences prefData = getSharedPreferences("fav_data", MODE_PRIVATE);
        if (isFav) {
            newIds.remove(favId);
            prefData.edit().remove(favId).apply();
            Toast.makeText(this, "Removed from Fav", Toast.LENGTH_SHORT).show();
            isFav = false;
        } else {
            newIds.add(favId);
            try {
                JSONObject obj = new JSONObject();
                obj.put("number", number); obj.put("language", language);
                obj.put("type", type); obj.put("title", title);
                obj.put("key", key); obj.put("body", body);
                prefData.edit().putString(favId, obj.toString()).apply();
            } catch (Exception e){}
            Toast.makeText(this, "Added to Fav", Toast.LENGTH_SHORT).show();
            isFav = true;
        }
        pref.edit().putStringSet("fav_ids", newIds).apply();
        updateFavIcon();
    }
}
