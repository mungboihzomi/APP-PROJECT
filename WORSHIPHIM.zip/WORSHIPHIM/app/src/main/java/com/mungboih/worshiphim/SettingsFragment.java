package com.mungboih.worshiphim;


import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        int BG = ThemeHelper.getBackground(getContext());
        int CARD_BG = ThemeHelper.getCardBackground(getContext());
        int TEXT = ThemeHelper.getTextColor(getContext());
        int SUB = ThemeHelper.getSubTextColor(getContext());

        LinearLayout root = new LinearLayout(getContext());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));

        TextView title = new TextView(getContext());
        title.setText("Settings");
        title.setTextColor(TEXT);
        title.setTextSize(22);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(0,0,0, dp(20));
        root.addView(title);

        // Dark Mode
        LinearLayout cardDark = makeCard(CARD_BG);
        LinearLayout textLayout = new LinearLayout(getContext());
        textLayout.setOrientation(LinearLayout.VERTICAL);
        textLayout.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        TextView tvDark = makeTitle("Dark Mode", TEXT);
        TextView tvSubDark = makeSub(ThemeHelper.isDarkMode(getContext()) ? "On" : "Off - Light mode", SUB);
        textLayout.addView(tvDark); textLayout.addView(tvSubDark);
        Switch switchDark = new Switch(getContext());
        switchDark.setChecked(ThemeHelper.isDarkMode(getContext()));
        cardDark.addView(textLayout); cardDark.addView(switchDark);
        root.addView(cardDark);
        switchDark.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
				@Override public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					ThemeHelper.setDarkMode(getContext(), isChecked);
					getActivity().recreate();
				}
			});

        // Text Size - fixed with final
        LinearLayout cardSize = makeCard(CARD_BG);
        cardSize.setOrientation(LinearLayout.VERTICAL);
        root.addView(cardSize);
        final TextView tvSizePreview = new TextView(getContext());
        tvSizePreview.setText("Aa Preview - WORSHIPHIM");
        tvSizePreview.setTextColor(TEXT); tvSizePreview.setGravity(Gravity.CENTER);
        tvSizePreview.setPadding(0, dp(10), 0, dp(10));
        final android.widget.SeekBar seekBar = new android.widget.SeekBar(getContext());
        seekBar.setMax(16);
        final android.content.SharedPreferences pref = getContext().getSharedPreferences("settings", android.content.Context.MODE_PRIVATE);
        int savedSize = pref.getInt("text_size", 17);
        seekBar.setProgress(savedSize - 12); tvSizePreview.setTextSize(savedSize);
        cardSize.addView(makeTitle("Text Size", TEXT));
        cardSize.addView(makeSub("Adjust lyrics size", SUB));
        cardSize.addView(tvSizePreview);
        cardSize.addView(seekBar, new LinearLayout.LayoutParams(-1, -2));
        seekBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
				@Override public void onProgressChanged(android.widget.SeekBar seekBar, int progress, boolean fromUser) {
					int size = progress + 12; tvSizePreview.setTextSize(size);
					pref.edit().putInt("text_size", size).apply();
				}
				@Override public void onStartTrackingTouch(android.widget.SeekBar seekBar) {}
				@Override public void onStopTrackingTouch(android.widget.SeekBar seekBar) {}
			});

        // Add New Songs -> Activity
        LinearLayout cardAdd = makeCard(CARD_BG);
        cardAdd.setOrientation(LinearLayout.VERTICAL);
        root.addView(cardAdd);
        cardAdd.addView(makeTitle("Add New Songs", TEXT));
        cardAdd.addView(makeSub("Tap to add new song to GitHub JSON", SUB));
        Button btnGoAdd = new Button(getContext());
        btnGoAdd.setText("+ Add New Song");
        btnGoAdd.setTextColor(Color.WHITE);
        btnGoAdd.setBackgroundColor(Color.parseColor("#36B9E9"));
        LinearLayout.LayoutParams goLp = new LinearLayout.LayoutParams(-1, dp(48));
        goLp.setMargins(0, dp(10), 0, 0);
        cardAdd.addView(btnGoAdd, goLp);
        btnGoAdd.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					Intent i = new Intent(getContext(), AddNewSongActivity.class);
					startActivity(i);
				}
			});

        // Admin
        LinearLayout cardAdmin = makeCard(CARD_BG);
        cardAdmin.setOrientation(LinearLayout.VERTICAL);
        root.addView(cardAdmin);
        cardAdmin.addView(makeTitle("Admin", TEXT));
        cardAdmin.addView(makeSub("Contact: mungboih@example.com", SUB));

        // About
        LinearLayout cardAbout = makeCard(CARD_BG);
        cardAbout.setOrientation(LinearLayout.VERTICAL);
        root.addView(cardAbout);
        cardAbout.addView(makeTitle("About", TEXT));
        TextView tvAbout = new TextView(getContext());
        tvAbout.setText("WORSHIPHIM v1.0 Offline\n1000+ Songs\n© 2026 Mung Boih");
        tvAbout.setTextColor(SUB); tvAbout.setTextSize(13); tvAbout.setPadding(0, dp(8), 0, 0);
        cardAbout.addView(tvAbout);

        return root;
    }

    private LinearLayout makeCard(int color){
        LinearLayout c=new LinearLayout(getContext()); c.setOrientation(LinearLayout.HORIZONTAL);
        c.setBackgroundColor(color); c.setPadding(dp(16),dp(14),dp(16),dp(14));
        c.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(14)); c.setLayoutParams(lp); return c;
    }
    private TextView makeTitle(String t,int color){ TextView tv=new TextView(getContext()); tv.setText(t); tv.setTextColor(color); tv.setTextSize(16); tv.setTypeface(null, Typeface.BOLD); return tv; }
    private TextView makeSub(String t,int color){ TextView tv=new TextView(getContext()); tv.setText(t); tv.setTextColor(color); tv.setTextSize(11); tv.setPadding(0,dp(2),0,dp(8)); return tv; }
    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}
