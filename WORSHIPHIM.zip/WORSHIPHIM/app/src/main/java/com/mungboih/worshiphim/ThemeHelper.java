package com.mungboih.worshiphim;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatDelegate;

public class ThemeHelper {

    private static final String PREF_NAME = "settings";
    private static final String KEY_DARK = "dark_mode";

    public static void applyTheme(Context context) {
        boolean isDark = isDarkMode(context);
        if (isDark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    public static boolean isDarkMode(Context context) {
        SharedPreferences pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return pref.getBoolean(KEY_DARK, true); // Default Dark
    }

    public static void setDarkMode(Context context, boolean isDark) {
        SharedPreferences pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        pref.edit().putBoolean(KEY_DARK, isDark).apply();
        applyTheme(context);
    }

    // Color Helper
    public static int getBackground(Context context) {
        return isDarkMode(context) ? 0xFF03111C : 0xFFF5F7FA;
    }
    public static int getCardBackground(Context context) {
        return isDarkMode(context) ? 0xFF0A2236 : 0xFFFFFFFF;
    }
    public static int getTextColor(Context context) {
        return isDarkMode(context) ? 0xFFFFFFFF : 0xFF1A1A1A;
    }
    public static int getSubTextColor(Context context) {
        return isDarkMode(context) ? 0xFFC3CDD7 : 0xFF6B7B8D;
    }
}
