package com.mungboih.worshiphim;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

public class HomeFragment extends Fragment {

    private final String JSON_URL = "https://raw.githubusercontent.com/mungboihzomi/Testing/main/allsongs.json";
    private final String CACHE_FILE = "hymns_cache.json";

    private LinearLayout tabBar, typeBar;
    private RecyclerView recyclerView;
    private EditText searchBox;
    private TextView status;
    private ProgressBar progress;
    private HymnAdapter adapter;

    private final ArrayList<JSONObject> allHymns = new ArrayList<JSONObject>();
    private final ArrayList<JSONObject> filteredHymns = new ArrayList<JSONObject>();

    private String selectedLanguage = "ZOMI";
    private String selectedType = "All";
    private String searchText = "";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    // Theme colors - onCreateView ထဲမှာ set မယ်
    private int BG, CARD_BG, TEXT_COLOR, SUB_COLOR;
    private final int BLUE = Color.rgb(54, 185, 233);

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        // Light / Dark ကာလာ
        BG = ThemeHelper.getBackground(getContext());
        CARD_BG = ThemeHelper.getCardBackground(getContext());
        TEXT_COLOR = ThemeHelper.getTextColor(getContext());
        SUB_COLOR = ThemeHelper.getSubTextColor(getContext());

        LinearLayout root = new LinearLayout(getContext());
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(18), dp(12), dp(18), dp(0));

        TextView logo = new TextView(getContext());
        logo.setText("WORSHIPHIM");
        logo.setTextSize(30);
        logo.setTextColor(TEXT_COLOR);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        logo.setPadding(0, dp(12), 0, dp(22));
        root.addView(logo, new LinearLayout.LayoutParams(-1, dp(76)));

        tabBar = new LinearLayout(getContext());
        tabBar.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(tabBar, new LinearLayout.LayoutParams(-1, dp(52)));
        addLanguageTab("ZOMI");
        addLanguageTab("MYANMAR");
        addLanguageTab("ENGLISH");

        searchBox = new EditText(getContext());
        searchBox.setSingleLine(true);
        searchBox.setTextSize(17);
        searchBox.setTextColor(TEXT_COLOR);
        searchBox.setHintTextColor(Color.GRAY);
        searchBox.setHint("Search song...");
        searchBox.setPadding(dp(16), 0, dp(16), 0);
        searchBox.setBackgroundColor(CARD_BG);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(54));
        sp.setMargins(0, dp(18), 0, dp(10));
        root.addView(searchBox, sp);

        HorizontalScrollView hv = new HorizontalScrollView(getContext());
        hv.setHorizontalScrollBarEnabled(false);
        typeBar = new LinearLayout(getContext());
        typeBar.setOrientation(LinearLayout.HORIZONTAL);
        hv.addView(typeBar);
        root.addView(hv, new LinearLayout.LayoutParams(-1, dp(48)));

        status = new TextView(getContext());
        status.setText("Loading hymns...");
        status.setTextSize(15);
        status.setTextColor(SUB_COLOR);
        status.setGravity(Gravity.CENTER);
        root.addView(status, new LinearLayout.LayoutParams(-1, dp(42)));

        progress = new ProgressBar(getContext());
        root.addView(progress, new LinearLayout.LayoutParams(-2, dp(36)));
        progress.setVisibility(View.VISIBLE);

        recyclerView = new RecyclerView(getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setBackgroundColor(BG);
        adapter = new HymnAdapter(getContext(), filteredHymns, new HymnAdapter.OnHymnClickListener() {
				@Override
				public void onClick(JSONObject hymn) {
					openDetail(hymn);
				}
			});
        recyclerView.setAdapter(adapter);
        root.addView(recyclerView, new LinearLayout.LayoutParams(-1, 0, 1f));

        searchBox.addTextChangedListener(new android.text.TextWatcher() {
				@Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
				@Override public void onTextChanged(CharSequence s, int start, int before, int count) {
					searchText = s.toString();
					renderList();
				}
				@Override public void afterTextChanged(android.text.Editable s) {}
			});

        // 1. Cache ကိုအရင်ဖတ် - Offline ရအောင်
        boolean hasCache = loadFromLocal();
        if (hasCache) {
            updateLanguageTabs();
            buildTypeFilters();
            renderList();
            status.setText("Offline - " + allHymns.size() + " songs");
            progress.setVisibility(View.GONE);
        }

        // 2. Internet ကနေ အသစ်ဒေါင်း
        loadFromInternet();

        return root;
    }

    private boolean loadFromLocal() {
        try {
            FileInputStream fis = getContext().openFileInput(CACHE_FILE);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            reader.close(); fis.close();
            JSONArray json = new JSONArray(sb.toString());
            allHymns.clear();
            for (int i = 0; i < json.length(); i++) {
                JSONObject obj = json.optJSONObject(i);
                if (obj != null) allHymns.add(obj);
            }
            return allHymns.size() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    private void saveToLocal(String jsonString) {
        try {
            FileOutputStream fos = getContext().openFileOutput(CACHE_FILE, Context.MODE_PRIVATE);
            fos.write(jsonString.getBytes("UTF-8"));
            fos.close();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void loadFromInternet() {
        progress.setVisibility(View.VISIBLE);
        if (allHymns.isEmpty()) status.setText("Loading hymns...");

        new Thread(new Runnable() {
				@Override
				public void run() {
					HttpURLConnection conn = null;
					try {
						URL url = new URL(JSON_URL);
						conn = (HttpURLConnection) url.openConnection();
						conn.setRequestMethod("GET");
						conn.setConnectTimeout(15000);
						conn.setReadTimeout(15000);
						int response = conn.getResponseCode();
						if (response != 200) throw new Exception("HTTP error: " + response);
						BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
						StringBuilder result = new StringBuilder();
						String line;
						while ((line = reader.readLine()) != null) result.append(line);
						reader.close();
						final String jsonString = result.toString();
						final JSONArray json = new JSONArray(jsonString);
						final ArrayList<JSONObject> loaded = new ArrayList<JSONObject>();
						for (int i = 0; i < json.length(); i++) {
							JSONObject obj = json.optJSONObject(i);
							if (obj != null) loaded.add(obj);
						}
						saveToLocal(jsonString);
						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									allHymns.clear();
									allHymns.addAll(loaded);
									progress.setVisibility(View.GONE);
									updateLanguageTabs();
									buildTypeFilters();
									renderList();
								}
							});
					} catch (final Exception e) {
						mainHandler.post(new Runnable() {
								@Override
								public void run() {
									progress.setVisibility(View.GONE);
									if (allHymns.isEmpty()) {
										status.setText("No internet & no offline data. Please connect once.");
									} else {
										status.setText("Offline - " + allHymns.size() + " songs");
									}
								}
							});
					} finally { if (conn != null) conn.disconnect(); }
				}
			}).start();
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private boolean isSameLanguage(String jsonLang, String sel) {
        if (jsonLang == null) return false;
        jsonLang = jsonLang.trim().toUpperCase(Locale.ROOT);
        sel = sel.trim().toUpperCase(Locale.ROOT);
        if (jsonLang.equals(sel)) return true;
        if (sel.equals("MYANMAR") && (jsonLang.equals("MM") || jsonLang.equals("MYANMAR"))) return true;
        if (sel.equals("ENGLISH") && (jsonLang.equals("EN") || jsonLang.equals("ENGLISH"))) return true;
        return false;
    }

    private void addLanguageTab(final String language) {
        final Button button = new Button(getContext());
        button.setText(language);
        button.setTextSize(14);
        button.setAllCaps(false);
        button.setBackgroundColor(Color.TRANSPARENT);
        tabBar.addView(button, new LinearLayout.LayoutParams(0, -1, 1f));
        button.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					selectedLanguage = language;
					selectedType = "All";
					updateLanguageTabs();
					buildTypeFilters();
					renderList();
				}
			});
    }

    private void updateLanguageTabs() {
        for (int i = 0; i < tabBar.getChildCount(); i++) {
            Button button = (Button) tabBar.getChildAt(i);
            String text = button.getText().toString();
            if (text.equalsIgnoreCase(selectedLanguage)) {
                button.setTextColor(BLUE);
                button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            } else {
                button.setTextColor(SUB_COLOR);
                button.setTypeface(Typeface.DEFAULT);
            }
        }
    }

    private void buildTypeFilters() {
        typeBar.removeAllViews();
        Set<String> types = new LinkedHashSet<String>();
        for (JSONObject hymn : allHymns) {
            String lang = hymn.optString("language", "");
            if (isSameLanguage(lang, selectedLanguage)) {
                String type = hymn.optString("type", "").trim();
                if (!type.isEmpty()) types.add(type);
            }
        }
        addTypeButton("All");
        for (String type : types) addTypeButton(type);
    }

    private void addTypeButton(final String type) {
        final Button button = new Button(getContext());
        button.setText(type);
        button.setTextSize(13);
        button.setAllCaps(false);
        button.setPadding(dp(14), 0, dp(14), 0);
        if (type.equals(selectedType)) {
            button.setTextColor(BLUE);
            button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        } else {
            button.setTextColor(SUB_COLOR);
        }
        button.setBackgroundColor(Color.TRANSPARENT);
        typeBar.addView(button, new LinearLayout.LayoutParams(-2, -1));
        button.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					selectedType = type;
					buildTypeFilters();
					renderList();
				}
			});
    }

    private void renderList() {
        filteredHymns.clear();
        String query = searchText.toLowerCase(Locale.ROOT).trim();
        for (JSONObject hymn : allHymns) {
            String lang = hymn.optString("language", "");
            if (!isSameLanguage(lang, selectedLanguage)) continue;
            String type = hymn.optString("type", "");
            if (!selectedType.equals("All") && !type.equalsIgnoreCase(selectedType)) continue;
            String searchable = (hymn.optString("title","") + " " + hymn.optString("number","") + " " + hymn.optString("body","")).toLowerCase(Locale.ROOT);
            if (!searchable.contains(query)) continue;
            filteredHymns.add(hymn);
        }
        Collections.sort(filteredHymns, new Comparator<JSONObject>() {
				@Override public int compare(JSONObject a, JSONObject b) {
					return Integer.compare(a.optInt("number", 0), b.optInt("number", 0));
				}
			});
        adapter.notifyDataSetChanged();
        if (filteredHymns.isEmpty() && !allHymns.isEmpty()) {
            status.setText("No songs in " + selectedLanguage);
        } else if (!allHymns.isEmpty()){
            status.setText(selectedLanguage + " - " + selectedType + " : " + filteredHymns.size());
        }
    }

    private void openDetail(JSONObject hymn) {
        Intent intent = new Intent(getContext(), DetailActivity.class);
        intent.putExtra("number", hymn.optString("number", ""));
        intent.putExtra("language", hymn.optString("language", ""));
        intent.putExtra("type", hymn.optString("type", ""));
        intent.putExtra("title", hymn.optString("title", ""));
        intent.putExtra("key", hymn.optString("key", ""));
        intent.putExtra("body", hymn.optString("body", ""));
        startActivity(intent);
    }
}
