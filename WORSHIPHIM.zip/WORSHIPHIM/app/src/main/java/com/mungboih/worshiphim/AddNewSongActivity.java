package com.mungboih.worshiphim;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class AddNewSongActivity extends AppCompatActivity {

    private EditText etNumber, etLanguage, etType, etTitle, etKey, etBody, etToken;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final String REPO_OWNER = "mungboihzomi";
    private final String REPO_NAME = "Testing";
    private final String FILE_PATH = "test.json";
    private final String BRANCH = "main";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeHelper.applyTheme(this);
        super.onCreate(savedInstanceState);

        int BG = ThemeHelper.getBackground(this);
        int TEXT = ThemeHelper.getTextColor(this);
        int SUB = ThemeHelper.getSubTextColor(this);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(18), dp(18), dp(18), dp(18));
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView btnBack = new TextView(this);
        btnBack.setText("← Back"); btnBack.setTextColor(TEXT); btnBack.setTextSize(16); btnBack.setPadding(dp(10), dp(10), dp(10), dp(10));
        btnBack.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { finish(); } });
        TextView title = new TextView(this);
        title.setText("Add New Song"); title.setTextColor(TEXT); title.setTextSize(20); title.setTypeface(null, Typeface.BOLD);
        title.setPadding(dp(20),0,0,0);
        header.addView(btnBack); header.addView(title);
        root.addView(header);

        TextView sub = new TextView(this);
        sub.setText("New song will be added to GitHub test.json");
        sub.setTextColor(SUB); sub.setTextSize(12); sub.setPadding(0, dp(10), 0, dp(20));
        root.addView(sub);

        final SharedPreferences pref = getSharedPreferences("settings", MODE_PRIVATE);

        etToken = makeEdit("GitHub Token ghp_xxx", TEXT);
        etToken.setText(pref.getString("github_token", ""));
        etNumber = makeEdit("Number e.g. 1024", TEXT);
        etLanguage = makeEdit("Language ZOMI / MYANMAR / ENGLISH", TEXT);
        etType = makeEdit("Type e.g. MMWOSHIP / HLAGU", TEXT);
        etTitle = makeEdit("Title *", TEXT);
        etKey = makeEdit("Key e.g. G (optional)", TEXT);
        etBody = makeEdit("Lyrics / Body *", TEXT);
        etBody.setMinLines(6); etBody.setGravity(Gravity.TOP);

        root.addView(etToken);
        root.addView(etNumber); root.addView(etLanguage); root.addView(etType);
        root.addView(etTitle); root.addView(etKey); root.addView(etBody);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(16), 0, 0);

        Button btnLocal = new Button(this); btnLocal.setText("SAVE LOCAL"); btnLocal.setTextColor(Color.WHITE); btnLocal.setBackgroundColor(Color.GRAY);
        Button btnPush = new Button(this); btnPush.setText("PUSH TO GITHUB"); btnPush.setTextColor(Color.WHITE); btnPush.setBackgroundColor(Color.parseColor("#36B9E9"));

        btnRow.addView(btnLocal, new LinearLayout.LayoutParams(0, dp(50), 1f));
        View sp = new View(this); sp.setLayoutParams(new LinearLayout.LayoutParams(dp(10), 1));
        btnRow.addView(sp);
        btnRow.addView(btnPush, new LinearLayout.LayoutParams(0, dp(50), 1f));
        root.addView(btnRow);

        btnLocal.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { saveLocal(); } });
        btnPush.setOnClickListener(new View.OnClickListener() {
				@Override public void onClick(View v) {
					String token = etToken.getText().toString().trim();
					if(token.isEmpty()){ Toast.makeText(AddNewSongActivity.this, "Paste Token first", Toast.LENGTH_SHORT).show(); return; }
					pref.edit().putString("github_token", token).apply();
					pushToGitHub();
				}
			});

        setContentView(scroll);
    }

    private void saveLocal(){
        String number = etNumber.getText().toString().trim();
        String language = etLanguage.getText().toString().trim();
        String type = etType.getText().toString().trim();
        String title = etTitle.getText().toString().trim();
        String key = etKey.getText().toString().trim();
        String body = etBody.getText().toString().trim();
        if(title.isEmpty() || body.isEmpty()){ Toast.makeText(this, "Title & Lyrics required", Toast.LENGTH_SHORT).show(); return; }
        if(language.isEmpty()) language="ZOMI"; if(type.isEmpty()) type="CUSTOM"; if(number.isEmpty()) number=String.valueOf(System.currentTimeMillis()%10000);
        try{
            JSONObject newSong = new JSONObject();
            newSong.put("number", number); newSong.put("language", language.toUpperCase()); newSong.put("type", type);
            newSong.put("title", title); newSong.put("key", key); newSong.put("body", body);
            JSONArray arr = new JSONArray();
            try{ FileInputStream fis=openFileInput("custom_songs.json"); BufferedReader r=new BufferedReader(new InputStreamReader(fis,"UTF-8")); StringBuilder sb=new StringBuilder(); String l; while((l=r.readLine())!=null) sb.append(l); r.close(); fis.close(); arr=new JSONArray(sb.toString()); }catch(Exception e){}
            arr.put(newSong);
            FileOutputStream fos=openFileOutput("custom_songs.json", Context.MODE_PRIVATE); fos.write(arr.toString().getBytes("UTF-8")); fos.close();
            Toast.makeText(this, "Saved Locally", Toast.LENGTH_LONG).show();
            etNumber.setText(""); etTitle.setText(""); etBody.setText("");
        }catch(Exception e){ Toast.makeText(this, "Fail", Toast.LENGTH_SHORT).show(); }
    }

    private void pushToGitHub(){
        Toast.makeText(this, "Pushing to GitHub...", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
				@Override public void run() {
					try{
						String token = etToken.getText().toString().trim();
						String number = etNumber.getText().toString().trim();
						String language = etLanguage.getText().toString().trim();
						String type = etType.getText().toString().trim();
						String title = etTitle.getText().toString().trim();
						String key = etKey.getText().toString().trim();
						String body = etBody.getText().toString().trim();
						if(title.isEmpty() || body.isEmpty()) throw new Exception("Title & Body required");
						if(language.isEmpty()) language="ZOMI"; if(type.isEmpty()) type="CUSTOM"; if(number.isEmpty()) number=String.valueOf(System.currentTimeMillis()%10000);

						String apiUrl = "https://api.github.com/repos/"+REPO_OWNER+"/"+REPO_NAME+"/contents/"+FILE_PATH;
						HttpURLConnection getConn = (HttpURLConnection) new URL(apiUrl).openConnection();
						getConn.setRequestProperty("Authorization", "token "+token);
						getConn.setRequestProperty("Accept", "application/vnd.github.v3+json");
						BufferedReader br=new BufferedReader(new InputStreamReader(getConn.getInputStream()));
						StringBuilder resp=new StringBuilder(); String line; while((line=br.readLine())!=null) resp.append(line); br.close();
						JSONObject getJson=new JSONObject(resp.toString());
						String sha=getJson.getString("sha");
						String contentBase64=getJson.getString("content").replace("\n","");
						String contentStr=new String(Base64.decode(contentBase64, Base64.DEFAULT),"UTF-8");
						JSONArray currentArr=new JSONArray(contentStr);

						JSONObject newSong=new JSONObject();
						newSong.put("number", number); newSong.put("language", language.toUpperCase()); newSong.put("type", type);
						newSong.put("title", title); newSong.put("key", key); newSong.put("body", body);
						currentArr.put(newSong);

						String newContent=currentArr.toString();
						String newContentBase64=Base64.encodeToString(newContent.getBytes("UTF-8"), Base64.NO_WRAP);

						JSONObject putData=new JSONObject();
						putData.put("message", "Add song: "+title+" by WORSHIPHIM App");
						putData.put("content", newContentBase64);
						putData.put("sha", sha); putData.put("branch", BRANCH);

						HttpURLConnection putConn=(HttpURLConnection) new URL(apiUrl).openConnection();
						putConn.setRequestMethod("PUT"); putConn.setDoOutput(true);
						putConn.setRequestProperty("Authorization", "token "+token);
						putConn.setRequestProperty("Accept", "application/vnd.github.v3+json");
						putConn.setRequestProperty("Content-Type", "application/json");
						OutputStream os=putConn.getOutputStream(); os.write(putData.toString().getBytes("UTF-8")); os.close();

						int code=putConn.getResponseCode();
						if(code==200 || code==201){
							handler.post(new Runnable() { @Override public void run() { Toast.makeText(AddNewSongActivity.this, "Success! Pushed to GitHub", Toast.LENGTH_LONG).show(); finish(); } });
						}else{
							BufferedReader err=new BufferedReader(new InputStreamReader(putConn.getErrorStream())); StringBuilder errSb=new StringBuilder(); String l; while((l=err.readLine())!=null) errSb.append(l);
							throw new Exception("GitHub error "+code+": "+errSb.toString());
						}
					}catch(final Exception e){
						handler.post(new Runnable() { @Override public void run() { Toast.makeText(AddNewSongActivity.this, "Push failed: "+e.getMessage(), Toast.LENGTH_LONG).show(); } });
					}
				}
			}).start();
    }

    private EditText makeEdit(String hint, int textColor){
        EditText et=new EditText(this); et.setHint(hint); et.setTextColor(textColor); et.setHintTextColor(Color.GRAY); et.setTextSize(14);
        et.setBackgroundColor(Color.parseColor("#102030")); et.setPadding(dp(14),dp(12),dp(14),dp(12));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,dp(10)); et.setLayoutParams(lp); return et;
    }
    private int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
}
